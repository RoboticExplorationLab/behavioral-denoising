# Paper benchmark results

Cost / expert is the mean ± sample standard deviation of method/expert cost ratios, paired by start and computed over successful trials only. Successful subsets differ between methods. A single successful trial has no standard deviation; no successes gives —.

Reacher success requires all five references within 10 s and no recorded height above 0.1 m. The paired expert cost is not filtered by expert height violations.

| Task | Method | Successes | Cost / expert |
|---|---|---:|---:|
| Cartpole | BD-χ² | 10/10 | 1.485 ± 0.097 |
| Cartpole | Select-DPC | 4/10 | 3.257 ± 1.116 |
| Cartpole | BD-mean | 0/10 | — |
| Cartpole | BD-sample | 0/10 | — |
| Cartpole | BD-KL | 0/10 | — |
| Cartpole | BD-mean-χ² | 10/10 | 1.194 ± 0.108 |
| Cartpole | Windowed DeePC | 0/10 | — |
| Cartpole | DeePC | 1/10 | 3.903 |
| Rocket | BD-χ² | 10/10 | 1.036 ± 0.047 |
| Rocket | Select-DPC | 6/10 | 1.155 ± 0.223 |
| Rocket | BD-mean | 4/10 | 1.425 ± 0.746 |
| Rocket | BD-sample | 3/10 | 1.404 ± 0.636 |
| Rocket | BD-KL | 0/10 | — |
| Rocket | BD-mean-χ² | 10/10 | 1.045 ± 0.049 |
| Rocket | Windowed DeePC | 1/10 | 1.050 |
| Rocket | DeePC | 1/10 | 2.853 |
| Reacher | BD-χ² | 7/10 | 1.104 ± 0.156 |
| Reacher | Select-DPC | 7/10 | 1.522 ± 0.402 |
| Reacher | BD-mean | 0/10 | — |
| Reacher | BD-sample | 0/10 | — |
| Reacher | BD-KL | 0/10 | — |
| Reacher | BD-mean-χ² | 4/10 | 1.047 ± 0.050 |
| Reacher | Windowed DeePC | 0/10 | — |
| Reacher | DeePC | 0/10 | — |

Push-T score is maximum post-action coverage / 0.95, capped at one. Success requires coverage strictly above 95% within 300 actions.

| Method | Successes | Mean score ± sample SD | Median score |
|---|---:|---:|---:|
| BD-χ² | 19/50 | 0.6606 ± 0.4534 | 0.981 |
| Select-DPC | 0/50 | 0.0661 ± 0.1222 | 0.000 |

Action timing: mean ± sample SD of three equally weighted per-start process-CPU means (ms/action), one numerical thread. Setup, simulation and Rocket touchdown overrides are excluded. These were affinity-controlled measurements under monitored background load, not an unloaded-machine comparison.

| Task | Method | CPU ms/action |
|---|---|---:|
| Cartpole | BD-χ² | 0.316 ± 0.011 |
| Cartpole | Select-DPC | 73.041 ± 2.884 |
| Cartpole | BD-mean | 0.138 ± 0.006 |
| Cartpole | BD-sample | 0.736 ± 0.016 |
| Cartpole | BD-KL | — |
| Cartpole | BD-mean-χ² | 0.140 ± 0.001 |
| Cartpole | Windowed DeePC | 124.029 ± 7.801 |
| Cartpole | DeePC | 4852.860 ± 1858.596 |
| Rocket | BD-χ² | 0.423 ± 0.008 |
| Rocket | Select-DPC | 2503.904 ± 600.060 |
| Rocket | BD-mean | 0.162 ± 0.004 |
| Rocket | BD-sample | 1.145 ± 0.011 |
| Rocket | BD-KL | — |
| Rocket | BD-mean-χ² | 0.184 ± 0.003 |
| Rocket | Windowed DeePC | 3319.915 ± 277.519 |
| Rocket | DeePC | 54202.486 ± 2224.949 |
| Reacher | BD-χ² | 0.546 ± 0.035 |
| Reacher | Select-DPC | 2279.036 ± 1170.772 |
| Reacher | BD-mean | 0.195 ± 0.016 |
| Reacher | BD-sample | 1.144 ± 0.024 |
| Reacher | BD-KL | — |
| Reacher | BD-mean-χ² | 0.259 ± 0.034 |
| Reacher | Windowed DeePC | 459.310 ± 119.924 |
| Reacher | DeePC | 42993.336 ± 20845.229 |

BD-KL produces no actions in the paper trials, so its action timing is undefined.
